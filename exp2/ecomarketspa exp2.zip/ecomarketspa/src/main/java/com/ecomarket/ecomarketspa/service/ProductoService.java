package com.ecomarket.ecomarketspa.service;

import java.util.List;

import com.ecomarket.ecomarketspa.model.Producto;

public interface ProductoService {
    Producto crearProducto(Producto producto);
    List<Producto> listarProductos();
    Producto obtenerProductoPorId(Long id);
    Producto actualizarProducto(Long id, Producto productoActualizado);
    Producto actualizarStock(Long id, Integer cantidad);
    void eliminarProducto(Long id);

}
