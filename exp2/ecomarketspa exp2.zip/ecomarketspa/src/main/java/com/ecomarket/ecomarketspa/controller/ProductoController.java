package com.ecomarket.ecomarketspa.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ecomarket.ecomarketspa.model.Producto;
import com.ecomarket.ecomarketspa.service.ProductoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;



@Tag (name = "Productos", description = "Operaciones de testeo con Productos")
@RestController
@RequestMapping("/api/productos")
public class ProductoController {

    private final ProductoService productoService;


    public ProductoController (ProductoService productoService) {
        this.productoService = productoService;
    }

    

    @Operation(summary = "Crear Producto", description = "Registra un nuevo producto en el sistema")
    @ApiResponse(responseCode = "201", description = "Producto Creado exitosamente!",
    content = @Content(mediaType = "application/json", schema = @Schema(implementation = Producto.class)))
    @PostMapping
    public ResponseEntity<Producto> crearProducto(@RequestBody Producto producto) {
        Producto nuevoProducto = productoService.crearProducto(producto);
        return new ResponseEntity<>(productoService.crearProducto(nuevoProducto), HttpStatus.CREATED);
    }

    @Operation(summary = "Listar Productos", description = "Obtener lista de todos los productos")
    @ApiResponse(responseCode = "200", description = "Lista de productos obtenida!",
    content = @Content(mediaType = "application/json", schema = @Schema(implementation = Producto[].class)))
    @GetMapping
    public ResponseEntity<List<Producto>> listarProductos() {
        List<Producto> productos = productoService.listarProductos();
        return ResponseEntity.ok(productos);
    }

    @Operation(summary = "Obtener Producto por ID", description = "Obtiene un Producto por su ID")
    @ApiResponse(responseCode = "200", description = "Producto Encontrado exitosamente!",
    content = @Content(mediaType = "application/json", schema = @Schema(implementation = Producto.class)))
    @ApiResponse(responseCode = "404", description = "Producto no encontrado")
    @GetMapping("/{id}")
    public ResponseEntity<Producto> obtenerProductoPorId(@PathVariable Long id) {
        Producto producto = productoService.obtenerProductoPorId(id);
        return ResponseEntity.ok(producto);
    }

    @Operation(summary = "Actualizar Producto", description = "Actualiza un Producto existente")
    @ApiResponse(responseCode = "200", description = "Producto Actualizado exitosamente!",
    content = @Content(mediaType = "application/json", schema = @Schema(implementation = Producto.class)))
    @ApiResponse(responseCode = "404", description = "Producto no encontrado")
    @PutMapping("/{id}")
    public ResponseEntity<Producto> actualizarProducto(@PathVariable Long id, @RequestBody Producto productoActualizado) {
        Producto producto = productoService.actualizarProducto(id, productoActualizado);
        return ResponseEntity.ok(producto);
    }

    @Operation(summary = "Actualizar Stock del Producto", description = "Actualiza el stock de un Producto")
    @ApiResponse(responseCode = "200", description = "Stock del producto actualizado exitosamente!",
    content = @Content(mediaType = "application/json", schema = @Schema(implementation = Producto.class)))
    @ApiResponse(responseCode = "404", description = "Producto no encontrado")
    @PatchMapping("/{id}/stock")
    public ResponseEntity<Producto> actualizarStock(@PathVariable Long id, @RequestParam Integer cantidad) {
        Producto producto = productoService.actualizarStock(id, cantidad);
        return ResponseEntity.ok(producto);
    }


    @Operation(summary = "Eliminar Producto", description = "Elimina un producto por su ID")
    @ApiResponse(responseCode = "204", description = "Producto eliminado exitosamente!")
    @ApiResponse(responseCode = "404", description = "Producto no encontrado")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarProducto(@PathVariable Long id) {
        productoService.eliminarProducto(id);
        return ResponseEntity.noContent().build();
    }


    

}
