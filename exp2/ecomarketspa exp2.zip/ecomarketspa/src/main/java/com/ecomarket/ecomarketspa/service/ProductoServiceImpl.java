package com.ecomarket.ecomarketspa.service;

import java.util.List;


import org.springframework.stereotype.Service;

import com.ecomarket.ecomarketspa.model.Producto;
import com.ecomarket.ecomarketspa.repository.ProductoRepository;

@Service
public class ProductoServiceImpl implements ProductoService {

    private final ProductoRepository productoRepository;


    public ProductoServiceImpl(ProductoRepository productoRepository) {
        this.productoRepository = productoRepository;
    }


    @Override
    public Producto crearProducto(Producto producto) {
        return productoRepository.save(producto);
        
    }

    @Override
    public List<Producto> listarProductos() {
        return productoRepository.findAll();
    }

    @Override
    public Producto obtenerProductoPorId(Long id) {
        return productoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Producto no encontrado"));
    }

    @Override
    public Producto actualizarProducto(Long id, Producto productoActualizado) {
        Producto productoExistente = obtenerProductoPorId(id);
        productoExistente.setNombre(productoActualizado.getNombre());
        productoExistente.setDescripcion(productoActualizado.getDescripcion());
        productoExistente.setPrecio(productoActualizado.getPrecio());
        
        if (productoActualizado.getStock() < 0) {
            throw new IllegalArgumentException("El stock no puede ser negativo");
        }
        productoExistente.setStock(productoActualizado.getStock());
        return productoRepository.save(productoExistente);
    }

    @Override
    public Producto actualizarStock(Long id, Integer cantidad) {
        Producto producto = obtenerProductoPorId(id);
        int nuevoStock = producto.getStock() + cantidad;
        if (nuevoStock < 0) {
            throw new IllegalArgumentException("El stock no puede ser negativo");
        }
        producto.setStock(nuevoStock);
        return productoRepository.save(producto);
    }

    @Override
    public void eliminarProducto(Long id) {
        productoRepository.deleteById(id);
    }



}
