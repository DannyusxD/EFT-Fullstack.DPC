package com.ecomarket.ecomarketspa.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecomarket.ecomarketspa.model.Pedido;
import java.util.List;


public interface PedidoRepository extends JpaRepository<Pedido, Long> {

    List<Pedido> findByUsuarioId(Long usuarioId);
    List<Pedido> findByEstado(String estado);

}
