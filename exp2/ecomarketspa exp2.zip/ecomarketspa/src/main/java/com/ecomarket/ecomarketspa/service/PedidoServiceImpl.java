package com.ecomarket.ecomarketspa.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ecomarket.ecomarketspa.model.Pedido;
import com.ecomarket.ecomarketspa.repository.PedidoRepository;

@Service
public class PedidoServiceImpl implements PedidoService {

    private final PedidoRepository pedidoRepository;

    
    public PedidoServiceImpl(PedidoRepository pedidoRepository) {
        this.pedidoRepository = pedidoRepository;
    }

    @Override
    public Pedido crearPedido(Pedido pedido) {
        validarPedido(pedido);
        return pedidoRepository.save(pedido);
    }

    @Override
    public List<Pedido> listarPedidos() {
        return pedidoRepository.findAll();
    }

    @Override
    public Pedido obtenerPedidoPorId(Long id) {
        return pedidoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado con id: " + id));
    }

    @Override
    public Pedido actualizarEstado(Long id, String estado) {
        Pedido pedido = pedidoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pedido no encontrado"));

        pedido.setEstado(estado);
        return pedidoRepository.save(pedido);
    }

    @Override
    public void eliminarPedido(Long id) {
        pedidoRepository.deleteById(id);
    }

    private void validarPedido(Pedido pedido) {
        if (pedido.getUsuarioId()== null) {
            throw new IllegalArgumentException("El ID del usuario es requerido");
        }

        if (pedido.getProductoId() == null) {
            throw new IllegalArgumentException("El ID del producto es requerido");
        }
        if (pedido.getCantidad() == null || pedido.getCantidad() <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser mayor que cero");
        } 
    }
    

}
