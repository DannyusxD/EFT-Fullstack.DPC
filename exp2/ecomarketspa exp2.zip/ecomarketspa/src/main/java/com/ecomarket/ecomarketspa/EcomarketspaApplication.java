package com.ecomarket.ecomarketspa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcomarketspaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcomarketspaApplication.class, args);
		
	}

	

}
