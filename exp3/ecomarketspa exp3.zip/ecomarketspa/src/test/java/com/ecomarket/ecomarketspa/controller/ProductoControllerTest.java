package com.ecomarket.ecomarketspa.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.ecomarket.ecomarketspa.model.Producto;
import com.ecomarket.ecomarketspa.service.ProductoServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
@AutoConfigureMockMvc
public class ProductoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private ProductoServiceImpl productoServiceImpl;

    List<Producto> listarProductos;

    private Producto producto;

    @BeforeEach
    void setUp() {
        producto = new Producto();
        producto.setId(1L);
        producto.setNombre("Producto Test");
        producto.setDescripcion("Descripcion del producto de prueba");
        producto.setPrecio(100.0);
        producto.setStock(10);

        listarProductos = List.of(producto, new Producto(2L, "Producto 2", "Descripcion del producto 2", 200.0, 5));
    }

    @Test
    public void testCrearProducto() throws Exception {
        Producto nuevoProducto = new Producto(1L, "Producto Test", "Descripcion del producto de prueba", 100.0, 10);
        when(productoServiceImpl.crearProducto(any(Producto.class))).thenReturn(nuevoProducto);
        mockMvc.perform(post("/api/productos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(nuevoProducto)))
                .andExpect(status().isCreated());
    }

    @Test
    public void testListarProductos() throws Exception {
        when(productoServiceImpl.listarProductos()).thenReturn(listarProductos);
        mockMvc.perform(get("/api/productos")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testObtenerProductoPorId() throws Exception {
        when(productoServiceImpl.obtenerProductoPorId(1L)).thenReturn(producto);
        mockMvc.perform(get("/api/productos/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testActualizarProducto() throws Exception {
        Producto productoOriginal = new Producto(1L, "Producto Original", "Descripcion original", 50.0, 5);
        Producto productoActualizado = new Producto(1L, "Producto Actualizado", "Descripcion actualizada", 150.0, 20);

        when(productoServiceImpl.actualizarProducto(any(Long.class), any(Producto.class))).thenReturn(productoActualizado);

        mockMvc.perform(post("/api/productos")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(productoOriginal)))
            .andExpect(status().isCreated());

        mockMvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put("/api/productos/1")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(productoActualizado)))
            .andExpect(status().isOk());
    }

    @Test
    public void actualizarStockTest() throws Exception {
        Producto productoConNuevoStock = new Producto(1L, "Producto Test", "Descripcion del producto de prueba", 100.0, 50);
        when(productoServiceImpl.actualizarStock(1L, 50)).thenReturn(productoConNuevoStock);
        mockMvc.perform(patch("/api/productos/1/stock")
            .param("cantidad", "50")
            .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk());
    }
    
    @Test
    public void eliminarProductoTest() throws Exception {
        Producto productoEliminar = new Producto(2L, "Producto a Eliminar", "Descripcion del producto a eliminar", 300.0, 8);
        when(productoServiceImpl.crearProducto(any(Producto.class))).thenReturn(productoEliminar);
        when(productoServiceImpl.obtenerProductoPorId(2L)).thenReturn(productoEliminar);

        // Crear el producto
        mockMvc.perform(post("/api/productos")
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(productoEliminar)))
            .andExpect(status().isCreated());

        // Eliminar el producto
        org.mockito.Mockito.doNothing().when(productoServiceImpl).eliminarProducto(2L);

        mockMvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders
            .delete("/api/productos/2"))
            .andExpect(status().isNoContent());
    }


    // Test para verificar que un producto no existe y se retorna un 404 Not Found
/*  @Test
    public void productoNoExisteTest() throws Exception {
        when(productoServiceImpl.obtenerProductoPorId(100L)).thenReturn(null);
        mockMvc.perform(get("/api/productos/100")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }
*/

}
