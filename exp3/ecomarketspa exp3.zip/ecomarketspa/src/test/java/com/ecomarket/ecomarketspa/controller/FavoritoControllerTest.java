package com.ecomarket.ecomarketspa.controller;


import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.ecomarket.ecomarketspa.model.Favorito;
import com.ecomarket.ecomarketspa.model.Producto;
import com.ecomarket.ecomarketspa.model.Usuario;
import com.ecomarket.ecomarketspa.service.FavoritoServiceImpl;


@SpringBootTest
@AutoConfigureMockMvc
public class FavoritoControllerTest {

    @Autowired
    private MockMvc mockMvc;

  

    @MockitoBean
    private FavoritoServiceImpl favoritoServiceImpl;

   

    private Usuario usuario;
    private Producto producto;
    private Favorito favorito;

    @BeforeEach
    void setUp() {
        usuario = new Usuario(1L, "Juan Perez", "juan@test.com", "password", null);
        producto = new Producto(1L, "Cepillo Bambú", "Descripción", 4.5, 100);
        favorito = new Favorito(1L, usuario, producto);
    }

    @Test
    public void testAgregarFavorito() throws Exception {
        when(favoritoServiceImpl.agregarFavorito(anyLong(), anyLong())).thenReturn(favorito);

        mockMvc.perform(post("/api/favoritos")
                .param("usuarioId", "1")
                .param("productoId", "1"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.usuario.id").value(1L))
                .andExpect(jsonPath("$.producto.id").value(1L));

        verify(favoritoServiceImpl, times(1)).agregarFavorito(1L, 1L);
    }

    @Test
    public void testAgregarFavorito_DatosInvalidos() throws Exception {
        mockMvc.perform(post("/api/favoritos")
                .param("usuarioId", "")
                .param("productoId", "1"))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void testEliminarFavorito() throws Exception {
        doNothing().when(favoritoServiceImpl).eliminarFavorito(anyLong(), anyLong());

        mockMvc.perform(delete("/api/favoritos") // Cambiado a DELETE
                .param("usuarioId", "1")
                .param("productoId", "1"))
                .andExpect(status().isNoContent());

        verify(favoritoServiceImpl, times(1)).eliminarFavorito(1L, 1L);
    }

    @Test
    public void testObtenerFavoritosPorUsuario() throws Exception {
        List<Favorito> favoritos = List.of(favorito);
        when(favoritoServiceImpl.obtenerFavoritosPorUsuario(1L)).thenReturn(favoritos);
        mockMvc.perform(get("/api/favoritos/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1L))
                .andExpect(jsonPath("$[0].usuario.id").value(1L))
                .andExpect(jsonPath("$[0].producto.id").value(1L)); 
    verify(favoritoServiceImpl, times(1)).obtenerFavoritosPorUsuario(1L);
    }

  
}
