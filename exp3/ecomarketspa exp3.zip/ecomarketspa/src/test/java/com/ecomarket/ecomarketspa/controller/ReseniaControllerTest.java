package com.ecomarket.ecomarketspa.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.junit.jupiter.api.BeforeEach;
import com.ecomarket.ecomarketspa.model.Resenia;
import com.ecomarket.ecomarketspa.repository.ReseniaRepository;
import com.ecomarket.ecomarketspa.service.ReseniaServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
@AutoConfigureMockMvc
public class ReseniaControllerTest {
    
    @MockBean
    private ReseniaRepository reseniaRepository;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private ReseniaServiceImpl reseniaService;

    List<Resenia> listarResenias;

    private Resenia resenia;

    @BeforeEach
    void setUp() {
        resenia = new Resenia();
        resenia.setId(1L);
        resenia.setCalificacion(4.5);
        resenia.setComentario("Excelente producto");
        resenia.setFechaCreacion(java.time.LocalDateTime.now());
        listarResenias = List.of(resenia, new Resenia(2L, null, null, 3.0, "Producto regular", java.time.LocalDateTime.now()));
    }

 

    @Test
    public void crearResenia() throws Exception {
        Resenia resenia = new Resenia();
        when(reseniaService.crearResenia(any(Resenia.class))).thenReturn(resenia);
        mockMvc.perform(post("/api/resenias")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(resenia)))
                .andExpect(status().isCreated());
    }

    @Test
    public void listarResenias() throws Exception {
        List<Resenia> resenias = List.of(resenia, new Resenia(2L, null, null, 3.0, "Producto regular", java.time.LocalDateTime.now()));
        when(reseniaService.listarResenias()).thenReturn(resenias);
        mockMvc.perform(get("/api/resenias"))
                .andExpect(status().isOk())
                .andExpect(result -> {
                    String content = result.getResponse().getContentAsString();
                    List<Resenia> reseniasResponse = objectMapper.readValue(content, objectMapper.getTypeFactory().constructCollectionType(List.class, Resenia.class));
                    assertNotNull(reseniasResponse);
                    assertEquals(2, reseniasResponse.size());
                });
    }

    @Test
    public void crearReseniaInvalida() throws Exception {
        Resenia resenia = new Resenia();
        resenia.setCalificacion(6.0); // Calificación inválida
        when(reseniaService.crearResenia(any(Resenia.class))).thenThrow(new IllegalArgumentException("La calificación debe estar entre 1 y 5"));

        mockMvc.perform(post("/api/resenias")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(resenia)))
                .andExpect(status().isBadRequest());
    }

}
