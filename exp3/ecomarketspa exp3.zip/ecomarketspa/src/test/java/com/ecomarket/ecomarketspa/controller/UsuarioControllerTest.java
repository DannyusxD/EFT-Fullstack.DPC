package com.ecomarket.ecomarketspa.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.fail;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.ecomarket.ecomarketspa.model.Usuario;
import com.ecomarket.ecomarketspa.service.UsuarioServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
@AutoConfigureMockMvc
public class UsuarioControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private UsuarioServiceImpl usuarioServiceImpl;

    List<Usuario> listaUsuarios;

    private Usuario usuario;

    @BeforeEach
    void setUp() {
        usuario = new Usuario();
        usuario.setId(1L);
        usuario.setNombre("Victor Baeza");
        usuario.setEmail("victorbaeza@email.com");
        usuario.setContrasena("contrasena123");
    }

    @Test
    public void crearUsuarioTest() throws Exception {
        Usuario nuevoUsuario = new Usuario(1L, "Victor Baeza", "victorbaeza@email.com", "contrasena123", null);
        Usuario otroUsuario = new Usuario(2L, "Daniel Paredes", "danielparedes@email.com", "contrasena456", null);
        when(usuarioServiceImpl.crearUsuario(any(Usuario.class))).thenReturn(otroUsuario);
        mockMvc.perform(post("/api/usuarios")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(nuevoUsuario)))
                .andExpect(status().isCreated());
    }

    @Test
    public void buscarUnUsuarioTest() throws Exception {
        Usuario unUsuario = new Usuario(1L, "Victor Baeza", "victorbaeza@email.com", "contrasena123", null);
        try {
            when(usuarioServiceImpl.obtenerUsuarioPorId(1L)).thenReturn(unUsuario);
            mockMvc.perform(get("/api/usuarios/1")
                    .contentType(MediaType.APPLICATION_JSON))
                    .andExpect(status().isOk());
        } catch (Exception ex) {
            fail("El testing ha capturado un error " + ex.getMessage());
        }
    }

    //aqui da error a proposito para ver si funciona el test
/*  @Test
    public void usuarioNoExisteTest() throws Exception {
        when(usuarioServiceImpl.obtenerUsuarioPorId(100L)).thenReturn(null);
        mockMvc.perform(get("/api/usuarios/100")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }
*/
    @Test
    public void verUsuariosTest() throws Exception {
        when(usuarioServiceImpl.listarUsuarios()).thenReturn(Arrays.asList(usuario));
        mockMvc.perform(get("/api/usuarios")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void eliminarUsuarioTest() throws Exception {
        Usuario nuevoUsuario = new Usuario(3L, "Nuevo Usuario", "nuevo@email.com", "password", null);
        when(usuarioServiceImpl.crearUsuario(any(Usuario.class))).thenReturn(nuevoUsuario);
        when(usuarioServiceImpl.obtenerUsuarioPorId(3L)).thenReturn(nuevoUsuario);
        mockMvc.perform(post("/api/usuarios")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(nuevoUsuario)))
                .andExpect(status().isCreated());
        mockMvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders
                .delete("/api/usuarios/3")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
                
    }
    @Test
    public void actualizarUsuarioTest() throws Exception {
        //crear un usuario inicial
        Usuario usuarioOriginal = new Usuario(4L, "Usuario Original", "original@email.com", "original123", null);
        when(usuarioServiceImpl.crearUsuario(any(Usuario.class))).thenReturn(usuarioOriginal);
        when(usuarioServiceImpl.obtenerUsuarioPorId(4L)).thenReturn(usuarioOriginal);

        mockMvc.perform(post("/api/usuarios")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(usuarioOriginal)))
                .andExpect(status().isCreated());

        //actualizar información del usuario
        Usuario usuarioActualizado = new Usuario(4L, "Usuario Actualizado", "actualizado@email.com", "nuevaPass", null);
        when(usuarioServiceImpl.actualizarUsuario(any(Long.class), any(Usuario.class))).thenReturn(usuarioActualizado);

        mockMvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders
                .put("/api/usuarios/4")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(usuarioActualizado)))
                .andExpect(status().isOk());
    }
}
