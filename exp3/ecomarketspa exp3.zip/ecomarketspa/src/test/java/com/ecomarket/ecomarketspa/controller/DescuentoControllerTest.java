package com.ecomarket.ecomarketspa.controller;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import com.ecomarket.ecomarketspa.model.Descuento;
import com.ecomarket.ecomarketspa.repository.DescuentoRepository;
import com.ecomarket.ecomarketspa.service.DescuentoServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;


@SpringBootTest
@AutoConfigureMockMvc
public class DescuentoControllerTest {

    
    @MockBean
    private DescuentoRepository reseniaRepository;

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private DescuentoServiceImpl descuentoServiceImpl;


    @Test
    public void crearDescuento() throws Exception {
        Descuento descuento = new Descuento();
        when(descuentoServiceImpl.crearDescuento(any(Descuento.class))).thenReturn(descuento);

        mockMvc.perform(post("/api/descuentos")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(descuento)))
                .andExpect(status().isCreated())
                .andExpect(result -> {
                    Descuento createdDescuento = objectMapper.readValue(result.getResponse().getContentAsString(), Descuento.class);
                    assertNotNull(createdDescuento);
                    assertEquals(descuento.getId(), createdDescuento.getId());
                });
    }

    @Test
    public void listarDescuentos() throws Exception {
        Descuento descuento1 = new Descuento();
        Descuento descuento2 = new Descuento();
        List<Descuento> descuentos = List.of(descuento1, descuento2);
        
        when(descuentoServiceImpl.listar()).thenReturn(descuentos);

        mockMvc.perform(get("/api/descuentos"))
                .andExpect(status().isOk())
                .andExpect(result -> {
                    List<Descuento> retrievedDescuentos = objectMapper.readValue(result.getResponse().getContentAsString(), List.class);
                    assertNotNull(retrievedDescuentos);
                    assertEquals(2, retrievedDescuentos.size());
                });
    }

    @Test
    public void obtenerDescuentoPorId() throws Exception {
        Descuento descuento = new Descuento();
        descuento.setId(1L);
        
        when(descuentoServiceImpl.obtenerPorId(1L)).thenReturn(java.util.Optional.of(descuento));

        mockMvc.perform(get("/api/descuentos/1"))
                .andExpect(status().isOk())
                .andExpect(result -> {
                    Descuento retrievedDescuento = objectMapper.readValue(result.getResponse().getContentAsString(), Descuento.class);
                    assertNotNull(retrievedDescuento);
                    assertEquals(1L, retrievedDescuento.getId());
                });
    }

  
    @Test
    public void actualizarDescuento() throws Exception {
        Descuento descuento = new Descuento();
        descuento.setId(1L);
        descuento.setCodigo("DESC10");
        descuento.setPorcentaje(10.0);
        descuento.setCategoria("Electrónica");
        descuento.setValidoHasta(java.time.LocalDate.now().plusDays(30));

        when(descuentoServiceImpl.actualizarDescuento(eq(1L), any(Descuento.class))).thenReturn(java.util.Optional.of(descuento));

        mockMvc.perform(put("/api/descuentos/1")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(descuento)))
                .andExpect(status().isOk())
                .andExpect(result -> {
                    Descuento updatedDescuento = objectMapper.readValue(result.getResponse().getContentAsString(), Descuento.class);
                    assertNotNull(updatedDescuento);
                    assertEquals("DESC10", updatedDescuento.getCodigo());
                    assertEquals(10.0, updatedDescuento.getPorcentaje());
                    assertEquals("Electrónica", updatedDescuento.getCategoria());
                });
    }

    @Test
    public void eliminarDescuento() throws Exception {
        Descuento descuento = new Descuento();
        descuento.setId(1L);
        when(descuentoServiceImpl.eliminarDescuento(1L)).thenReturn(true);
        doNothing().when(reseniaRepository).deleteById(1L);
        mockMvc.perform(delete("/api/descuentos/1"))
                .andExpect(status().isNoContent());
        verify(descuentoServiceImpl, times(1)).eliminarDescuento(1L);
    }

}
