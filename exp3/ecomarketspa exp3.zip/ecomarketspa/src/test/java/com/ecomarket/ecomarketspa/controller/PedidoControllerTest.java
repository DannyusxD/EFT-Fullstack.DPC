package com.ecomarket.ecomarketspa.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.ecomarket.ecomarketspa.service.PedidoServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ecomarket.ecomarketspa.model.Pedido;

@SpringBootTest
@AutoConfigureMockMvc
public class PedidoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private PedidoServiceImpl pedidoServiceImpl;

    List<Pedido> listarPedidos;

    private Pedido pedido;

    @BeforeEach
    public void setUp() {
        pedido = new Pedido();
        pedido.setId(1L);
        pedido.setUsuarioId(1L);
        pedido.setProductoId(1L);
        pedido.setCantidad(2);
        pedido.setEstado("PENDIENTE");
        pedido.setFechaCreacion(LocalDateTime.now());
        listarPedidos = List.of(pedido);
    }

    @Test
    public void testCrearPedido() throws Exception {
        Pedido nuevoPedido = new Pedido(1L, 1L, 1L, 2, "PENDIENTE", LocalDateTime.now());
        when(pedidoServiceImpl.crearPedido(any(Pedido.class))).thenReturn(nuevoPedido);
        mockMvc.perform(post("/api/pedidos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(nuevoPedido)))
                .andExpect(status().isCreated());
    }

    @Test
    public void testListarPedidos() throws Exception {
        when(pedidoServiceImpl.listarPedidos()).thenReturn(listarPedidos);
        mockMvc.perform(get("/api/pedidos")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testObtenerPedidoPorId() throws Exception {
        when(pedidoServiceImpl.obtenerPedidoPorId(1L)).thenReturn(pedido);
        mockMvc.perform(get("/api/pedidos/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void testActualizarEstadoPedido() throws Exception {
        Pedido pedidoActualizado = new Pedido(1L, 1L, 1L, 2, "COMPLETADO", LocalDateTime.now());
        when(pedidoServiceImpl.actualizarEstado(1L, "COMPLETADO")).thenReturn(pedidoActualizado);

        mockMvc.perform(patch("/api/pedidos/1/estado")
                .contentType(MediaType.APPLICATION_JSON)
                .content("\"COMPLETADO\"")) // Plain string without JSON object
                .andExpect(status().isOk());
    }

    @Test
    public void testEliminarPedido() throws Exception {
        Pedido pedidoAEliminar = new Pedido(1L, 1L, 1L, 2, "PENDIENTE", LocalDateTime.now());
        when(pedidoServiceImpl.obtenerPedidoPorId(1L)).thenReturn(pedidoAEliminar);
        mockMvc.perform(delete("/api/pedidos/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
    }

    

}
