package com.ecomarket.ecomarketspa.controller;

import com.ecomarket.ecomarketspa.model.Descuento;
import com.ecomarket.ecomarketspa.service.DescuentoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

import java.util.List;

@Tag(name = "Descuentos", description = "Operaciones de testeo con Descuentos")


@RestController
@RequestMapping("/api/descuentos")
public class DescuentoController {

    private final DescuentoService service;

    public DescuentoController(DescuentoService service) {
        this.service = service;
    }    @Operation(summary = "Crear descuento", description = "Crea un nuevo descuento")
    @ApiResponse(responseCode = "201", description = "Descuento creado exitosamente",
    content = @Content(mediaType = "application/json", schema = @Schema(implementation = Descuento.class)))
    @PostMapping
    public ResponseEntity<Descuento> crearDescuento(@RequestBody Descuento descuento) {
        Descuento nuevoDescuento = service.crearDescuento(descuento);
        return ResponseEntity.status(201).body(nuevoDescuento);
    }

    @Operation(summary = "Listar descuentos", description = "Obtiene todos los descuentos disponibles")
    @ApiResponse(responseCode = "200", description = "Lista de descuentos obtenida exitosamente",
    content = @Content(mediaType = "application/json", schema = @Schema(implementation = Descuento[].class)))
    @GetMapping
    public ResponseEntity<List<Descuento>> listarDescuentos() {
        List<Descuento> descuentos = service.listar();
        return ResponseEntity.ok(descuentos);
    }

    @Operation(summary = "Obtener descuento por ID", description = "Obtiene un descuento específico por su ID")
    @ApiResponse(responseCode = "200", description = "Descuento encontrado exitosamente",
    content = @Content(mediaType = "application/json", schema = @Schema(implementation = Descuento.class)))
    @ApiResponse(responseCode = "404", description = "Descuento no encontrado")
    @GetMapping("/{id}")
    public ResponseEntity<Descuento> obtenerDescuentoPorId(@PathVariable Long id) {
        return service.obtenerPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Actualizar descuento", description = "Actualiza un descuento existente")
    @ApiResponse(responseCode = "200", description = "Descuento actualizado exitosamente",
    content = @Content(mediaType = "application/json", schema = @Schema(implementation = Descuento.class)))
    @ApiResponse(responseCode = "404", description = "Descuento no encontrado")
    @PutMapping("/{id}")
    public ResponseEntity<Descuento> actualizarDescuento(@PathVariable Long id, @RequestBody Descuento descuento) {
        return service.actualizarDescuento(id, descuento)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Eliminar descuento", description = "Elimina un descuento por su ID")
    @ApiResponse(responseCode = "204", description = "Descuento eliminado exitosamente")
    @ApiResponse(responseCode = "404", description = "Descuento no encontrado")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarDescuento(@PathVariable Long id) {
        if (service.eliminarDescuento(id)) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }


    

    // no implementado bien todavia
    /* 
    @GetMapping("/aplicar")
    public ResponseEntity<?> aplicar(@RequestParam String codigo,
                                     @RequestParam double precioOriginal) {
        Optional<Descuento> desc = service.aplicarPorCodigo(codigo);

        if (desc.isEmpty()) {
            return ResponseEntity.status(404).body("Cupón inválido o expirado.");
        }

        double nuevoPrecio = service.calcularDescuento(precioOriginal, desc.get());

        return ResponseEntity.ok().body(new AplicacionDescuentoResponse(desc.get(), precioOriginal, nuevoPrecio));
    }
*/
    
    
}
