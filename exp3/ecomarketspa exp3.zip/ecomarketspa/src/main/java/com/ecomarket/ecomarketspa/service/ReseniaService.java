package com.ecomarket.ecomarketspa.service;

import java.util.List;

import com.ecomarket.ecomarketspa.model.Resenia;


public interface ReseniaService {
    List<Resenia> listarResenias();
    List<Resenia> obtenerReseniasPorProducto(Long productoId);
    Resenia crearResenia(Resenia resenia);
    void eliminarResenia(Long id);
}

