package com.ecomarket.ecomarketspa.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecomarket.ecomarketspa.model.Pedido;
import com.ecomarket.ecomarketspa.service.PedidoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "Pedidos", description = "Operaciones de testeo con Pedidos")
@RestController
@RequestMapping("/api/pedidos")
public class PedidoController {

    private final PedidoService pedidoService;
     
    
    public PedidoController(PedidoService pedidoService) {
        this.pedidoService = pedidoService;
    }


    @Operation(summary = "Crear Pedido", description = "Registra un nuevo pedido en el sistema")
    @ApiResponse(responseCode = "201", description = "Pedido Creado exitosamente!",
    content = @Content(mediaType = "application/json", schema = @Schema(implementation = Pedido.class)))
    @PostMapping
    public ResponseEntity<Pedido> crearPedido(@RequestBody Pedido pedido) {
        Pedido nuevoPedido = pedidoService.crearPedido(pedido);
        return new ResponseEntity<>(nuevoPedido, HttpStatus.CREATED);
    }

    @Operation(summary = "Listar Pedidos", description = "Obtener lista de todos los pedidos")
    @ApiResponse(responseCode = "200", description = "Lista de pedidos obtenida!",
    content = @Content(mediaType = "application/json", schema = @Schema(implementation = Pedido[].class)))
    @GetMapping
    public ResponseEntity<List<Pedido>> listarPedidos() {
        List<Pedido> pedidos = pedidoService.listarPedidos();
        return ResponseEntity.ok(pedidos);
    }

    @Operation(summary = "Obtener Pedido por ID", description = "Obtiene un Pedido por su ID")
    @ApiResponse(responseCode = "200", description = "Pedido Encontrado exitosamente!",
    content = @Content(mediaType = "application/json", schema = @Schema(implementation = Pedido.class)))
    @ApiResponse(responseCode = "404", description = "Pedido no encontrado")
    @GetMapping("/{id}")
    public ResponseEntity<Pedido> obtenerPedidoPorId(@PathVariable Long id) {
        Pedido pedido = pedidoService.obtenerPedidoPorId(id);
        return ResponseEntity.ok(pedido);
    }

    @Operation(summary = "Actualizar Estado del Pedido", description = "Actualiza el estado de un pedido")
    @ApiResponse(responseCode = "200", description = "Estado del pedido actualizado exitosamente!",
    content = @Content(mediaType = "application/json", schema = @Schema(implementation = Pedido.class)))
    @ApiResponse(responseCode = "404", description = "Pedido no encontrado")
    @PatchMapping("/{id}/estado")
    public Pedido actualizarEstado(
            @PathVariable Long id,
            @RequestBody String estado) {
        return pedidoService.actualizarEstado(id, estado);
    }

    @Operation(summary = "Eliminar Pedido", description = "Elimina un pedido por su ID")
    @ApiResponse(responseCode = "204", description = "Pedido eliminado exitosamente!")
    @ApiResponse(responseCode = "404", description = "Pedido no encontrado")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarPedido(@PathVariable Long id) {
        pedidoService.eliminarPedido(id);
        return ResponseEntity.noContent().build();
    }




}
