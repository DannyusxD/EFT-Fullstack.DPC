package com.ecomarket.ecomarketspa.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ecomarket.ecomarketspa.model.Usuario;



@Service
public interface UsuarioService {
    Usuario crearUsuario(Usuario usuario);
    List<Usuario> listarUsuarios();
    Usuario obtenerUsuarioPorId(Long id);
    Usuario actualizarUsuario(Long id, Usuario usuarioActualizado);
    void eliminarUsuario(Long id);
    boolean existeEmail(String email);

 
    
}
