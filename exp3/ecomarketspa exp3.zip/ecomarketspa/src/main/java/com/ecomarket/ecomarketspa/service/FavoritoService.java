package com.ecomarket.ecomarketspa.service;

import java.util.List;

import com.ecomarket.ecomarketspa.model.Favorito;

public interface FavoritoService {

    List<Favorito> obtenerFavoritosPorUsuario(Long usuarioId);
    Favorito agregarFavorito(Long usuarioId, Long productoId);
    void eliminarFavorito(Long usuarioId, Long productoId);
    

}
