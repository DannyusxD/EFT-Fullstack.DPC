package com.ecomarket.ecomarketspa.service;

import com.ecomarket.ecomarketspa.model.Descuento;
import java.util.List;
import java.util.Optional;


public interface  DescuentoService {

    Descuento crearDescuento(Descuento descuento);
    List<Descuento> listar();
    Optional<Descuento> obtenerPorId(Long id);
    Optional<Descuento> actualizarDescuento(Long id, Descuento descuento);
    boolean eliminarDescuento(Long id);
    //Optional<Descuento> aplicarPorCodigo(String codigo, double precioOriginal, LocalDate fechaAplicacion);

    
}