package com.ecomarket.ecomarketspa.model;

public class Modelo {

}
