package com.ecomarket.ecomarketspa.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.ecomarket.ecomarketspa.model.Resenia;

public interface ReseniaRepository extends JpaRepository<Resenia, Long> {
    
    List<Resenia> findByProductoId(@Param("productoId") Long productoId);
}