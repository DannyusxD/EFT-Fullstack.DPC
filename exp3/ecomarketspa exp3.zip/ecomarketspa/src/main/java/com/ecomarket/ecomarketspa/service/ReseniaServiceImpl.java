package com.ecomarket.ecomarketspa.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ecomarket.ecomarketspa.model.Resenia;
import com.ecomarket.ecomarketspa.repository.ReseniaRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ReseniaServiceImpl implements ReseniaService{


     private final ReseniaRepository reseniaRepository;

  
    public ReseniaServiceImpl(ReseniaRepository reseniaRepository) {
        this.reseniaRepository = reseniaRepository;
    }

    @Override
    public List<Resenia> listarResenias() {
        return reseniaRepository.findAll();
    }    @Override
    public List<Resenia> obtenerReseniasPorProducto(Long productoId) {
        return reseniaRepository.findByProductoId(productoId);
    }

    @Override
    public Resenia crearResenia(Resenia resenia) {

        if(resenia.getCalificacion() < 1 || resenia.getCalificacion() > 5) {
            throw new IllegalArgumentException("La calificación debe estar entre 1 y 5");
        }
        return reseniaRepository.save(resenia);
    }

    @Override
    public void eliminarResenia(Long id) {
        reseniaRepository.deleteById(id);
    }

}
