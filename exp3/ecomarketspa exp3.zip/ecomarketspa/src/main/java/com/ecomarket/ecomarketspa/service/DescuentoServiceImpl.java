package com.ecomarket.ecomarketspa.service;


import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.ecomarket.ecomarketspa.model.Descuento;
import com.ecomarket.ecomarketspa.repository.DescuentoRepository;

@Service
public class DescuentoServiceImpl implements DescuentoService {

    private final DescuentoRepository descuentoRepository;
    public DescuentoServiceImpl(DescuentoRepository descuentoRepository) {
        this.descuentoRepository = descuentoRepository;
    }

    @Override
    public Descuento crearDescuento(Descuento descuento) {
        return descuentoRepository.save(descuento);
    }
    @Override
    public List<Descuento> listar() {
        return descuentoRepository.findAll();
    }
    @Override
    public Optional<Descuento> obtenerPorId(Long id) {
        return descuentoRepository.findById(id);
    }
    @Override
    public Optional<Descuento> actualizarDescuento(Long id, Descuento descuento) {
        if (descuentoRepository.existsById(id)) {
            descuento.setId(id);
            return Optional.of(descuentoRepository.save(descuento));
        }
        return Optional.empty();
    }
    @Override
    public boolean eliminarDescuento(Long id) {
        if (descuentoRepository.existsById(id)) {
            descuentoRepository.deleteById(id);
            return true;
        }
        return false;
    }

    

}
