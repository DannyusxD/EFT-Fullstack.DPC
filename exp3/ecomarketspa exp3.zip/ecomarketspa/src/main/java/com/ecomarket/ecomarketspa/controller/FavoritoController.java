package com.ecomarket.ecomarketspa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ecomarket.ecomarketspa.model.Favorito;
import com.ecomarket.ecomarketspa.service.FavoritoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "Favoritos", description = "Operaciones de testeo con Favoritos")
@RestController
@RequestMapping("/api/favoritos")
public class FavoritoController {

    @Autowired
    private FavoritoService favoritoServiceImpl;

    @Operation(summary = "Obtener favoritos por usuario", description = "Obtiene todos los favoritos de un usuario específico")
    @ApiResponse(responseCode = "200", description = "Lista de favoritos obtenida exitosamente",
    content = @Content(mediaType = "application/json", schema = @Schema(implementation = Favorito[].class)))
    @GetMapping("/{usuarioId}")
    public ResponseEntity<List<Favorito>> obtenerFavoritosPorUsuario(@PathVariable Long usuarioId) {
        List<Favorito> favoritos = favoritoServiceImpl.obtenerFavoritosPorUsuario(usuarioId);
        return ResponseEntity.ok(favoritos);
    }    @Operation(summary = "Agregar favorito", description = "Agrega un producto a la lista de favoritos del usuario")
    @ApiResponse(responseCode = "201", description = "Favorito agregado exitosamente",
    content = @Content(mediaType = "application/json", schema = @Schema(implementation = Favorito.class)))
    @ApiResponse(responseCode = "400", description = "Datos inválidos")
    @PostMapping
    public ResponseEntity<Favorito> agregarFavorito(@RequestParam Long usuarioId, @RequestParam Long productoId) {
        Favorito favorito = favoritoServiceImpl.agregarFavorito(usuarioId, productoId);
        return ResponseEntity.status(HttpStatus.CREATED).body(favorito);
    }

    @Operation(summary = "Eliminar favorito", description = "Elimina un producto de la lista de favoritos del usuario")
    @ApiResponse(responseCode = "204", description = "Favorito eliminado exitosamente")
    @ApiResponse(responseCode = "404", description = "Favorito no encontrado")
    @DeleteMapping
    public ResponseEntity<Void> eliminarFavorito(@RequestParam Long usuarioId, @RequestParam Long productoId) {
        favoritoServiceImpl.eliminarFavorito(usuarioId, productoId);
        return ResponseEntity.noContent().build();
    }

}
