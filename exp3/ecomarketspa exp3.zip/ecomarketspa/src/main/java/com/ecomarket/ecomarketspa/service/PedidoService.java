package com.ecomarket.ecomarketspa.service;

import java.util.List;

import com.ecomarket.ecomarketspa.model.Pedido;

public interface PedidoService {
    Pedido crearPedido(Pedido pedido);
    List<Pedido> listarPedidos();
    Pedido obtenerPedidoPorId(Long id);
    Pedido actualizarEstado(Long id, String nuevoEstado);
    void eliminarPedido(Long id);

}
