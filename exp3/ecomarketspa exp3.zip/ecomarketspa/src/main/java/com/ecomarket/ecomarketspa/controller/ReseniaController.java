package com.ecomarket.ecomarketspa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecomarket.ecomarketspa.model.Resenia;
import com.ecomarket.ecomarketspa.service.ReseniaService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "Reseñas", description = "Operaciones de testeo con Reseñas")
@RestController
@RequestMapping("/api/resenias")
public class ReseniaController {

    @Autowired
     private final ReseniaService reseniaServiceImpl;


    
    public ReseniaController(ReseniaService reseniaService) {
        this.reseniaServiceImpl = reseniaService;
    }


    @Operation(summary = "Listar todas las reseñas", description = "Obtiene una lista de todas las reseñas disponibles")
    @ApiResponse(responseCode = "200", description = "Lista de reseñas obtenida exitosamente",
    content = @Content(mediaType = "application/json", schema = @Schema(implementation = Resenia.class)))
    @GetMapping
    public ResponseEntity<List<Resenia>> listarTodasResenias() {
        return ResponseEntity.ok(reseniaServiceImpl.listarResenias());
    }

    @Operation(summary = "Obtener reseñas por producto", description = "Obtiene todas las reseñas asociadas a un producto específico")
    @ApiResponse(responseCode = "200", description = "Reseñas obtenidas exitosamente",
    content = @Content(mediaType = "application/json", schema = @Schema(implementation = Resenia.class)))
    @GetMapping("/producto/{productoId}")
    public List<Resenia> obtenerReseniasPorProducto(@PathVariable Long productoId) {
        return reseniaServiceImpl.obtenerReseniasPorProducto(productoId);
    }

   
    @Operation(summary = "Crear una nueva reseña", description = "Registra una nueva reseña para un producto")
    @ApiResponse(responseCode = "201", description = "Reseña creada exitosamente",
    content = @Content(mediaType = "application/json", schema = @Schema(implementation = Resenia.class)))
    @PostMapping
    public ResponseEntity<Resenia> crearResenia(@RequestBody Resenia resenia) {
        Resenia nuevaResenia = reseniaServiceImpl.crearResenia(resenia);
        return new ResponseEntity<>(nuevaResenia, HttpStatus.CREATED);
    }

    @Operation(summary = "Eliminar una reseña", description = "Elimina una reseña por su ID")
    @ApiResponse(responseCode = "204", description = "Reseña eliminada exitosamente",
    content = @Content(mediaType = "application/json", schema = @Schema(implementation = Resenia.class)))
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarResenia(@PathVariable Long id) {
        reseniaServiceImpl.eliminarResenia(id);
        return ResponseEntity.noContent().build();
    }
    
}
