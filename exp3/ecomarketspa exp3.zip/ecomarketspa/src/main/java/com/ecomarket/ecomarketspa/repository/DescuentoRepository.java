package com.ecomarket.ecomarketspa.repository;

import com.ecomarket.ecomarketspa.model.Descuento;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface DescuentoRepository extends JpaRepository<Descuento, Long> {
    Optional<Descuento> findByCodigo(String codigo);
}