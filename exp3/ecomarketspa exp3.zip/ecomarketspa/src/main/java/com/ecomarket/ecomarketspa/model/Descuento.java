package com.ecomarket.ecomarketspa.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class Descuento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String codigo;
    private double porcentaje; 
    private String categoria; 
    private LocalDate validoHasta;
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getCodigo() {
        return codigo;
    }
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    public double getPorcentaje() {
        return porcentaje;
    }
    public void setPorcentaje(double porcentaje) {
        this.porcentaje = porcentaje;
    }
    public String getCategoria() {
        return categoria;
    }
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
    public LocalDate getValidoHasta() {
        return validoHasta;
    }
    public void setValidoHasta(LocalDate validoHasta) {
        this.validoHasta = validoHasta;
    }

    
}
